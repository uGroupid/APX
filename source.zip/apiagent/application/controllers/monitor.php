<?php
include_once(APPPATH ."/libraries/extends/crl.php");
class Monitor extends MY_Controller{
	public $crl;
	function __construct(){
		parent::__construct();
		$this->load->library('curl'); 
		$this->crl = new crl;
	}
	public function index2(){
			
			$min = 1002565;
			$max = 1003968;
			for($cate_id=$min; $cate_id < $max; $cate_id++){
				$minresponse = $this->curl->simple_post('https://e.vnexpress.net/category/loadmorenews', array('cate_id'=>$cate_id,'page'=>'2'));
				$response = json_decode($minresponse);
				if(!empty($response->message)){
					echo $cate_id. " | true";
				}
			}
	}
	public function index(){	
	
		
		$response = $this->curl->simple_get('https://raovat.vnexpress.net/category/loadmorenews', array('id'=>'1920','page'=>'1')); 
		// $response1003905 = $this->curl->simple_post('https://e.vnexpress.net/category/loadmorenews', array('cate_id'=>'1003905','page'=>'20')); 
		 
		//min$response1003907 = $this->curl->simple_post('https://e.vnexpress.net/category/loadmorenews', array('cate_id'=>'1002565','page'=>'99')); 
		// $maxresponse = $this->curl->simple_post('https://e.vnexpress.net/category/loadmorenews', array('cate_id'=>'1003967','page'=>'1')); 
		// $results = json_decode($response);
		// $results1003905 = json_decode($response1003905);
		$response = json_decode($minresponse);
		var_dump($response);
		echo $response->mesage;
		
		// for($i; $i <= $x; $i++){
			// $minresponse = $this->curl->simple_post('https://e.vnexpress.net/category/loadmorenews', array('cate_id'=>$i,'page'=>'1'));
			// $response = json_decode($minresponse);
			// echo $i .'|'.$response->error ."</br>";
		// }
		
		// $url = 'https://e.vnexpress.net/news/travel-life/travel/red-cotton-trees-in-full-bloom-across-northern-vietnam-3727985.html';
	
		// $crl_result = $this->crl_vnexpress_en($url);
	
		// echo "<pre>";
		// var_dump($crl_result);
		// echo "</pre>";
	}
	public function crl_vnexpress_en($url){
		if(!empty($url)){
			try {
				$namespaces = 2;
				$elements = "bg_title_post";
				$title_post = $this->crl->crawler_run($url,$namespaces,$elements);
				
				$namespaces = 2;
				$elements = "thumb_detail_top";
				$thumb_detail_top = $this->crl->crawler_run($url,$namespaces,$elements);
				
				$namespaces = 2;
				$elements = "lead_post_detail";
				$lead_post_detail = $this->crl->crawler_run($url,$namespaces,$elements);
				
				$namespaces = 2;
				$elements = "fck_detail";
				$details = $this->crl->crawler_run($url,$namespaces,$elements);
				
				$namespaces = 2;
				$elements = "tag_item";
				$tags = $this->crl->crawler_tags($url,$namespaces,$elements);
				$source = parse_url($url);
				return $response = array(
					'title_post'=> $title_post,
					'thumb_detail_top'=> $thumb_detail_top,
					'lead_post_detail'=> $lead_post_detail,
					'details'=> $details,
					'tags'=> $tags,
					'source'=> $source['host'],
				);
			} catch (Exception $e) { }
		}
	}
	
	
}
?>