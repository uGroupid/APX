<?php 

echo "API ";
?>