<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['es_server'] = 'http://vinaphone.vn:9200';
$config['index'] = '';