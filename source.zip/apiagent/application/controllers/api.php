<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Mongo_Controller.php';
class Api extends REST_Controller {
	function __construct(){
		parent::__construct();
		$this->logs_server();
		$this->key = keys();
		$this->load->model('global_model', 'GlobalMD');	
	}
	/*--------------------------*/
	public function index_get(){
		$response = array('OS'=> 'Core System API Agent');
		$this->response($response);
	}
	public function logs_server(){
		return $this->mongo_db->insert('logs_server',$_SERVER);
	}
	
	/*--------------------------*/
	
	
///---End Class Apps---///
}

	

?>